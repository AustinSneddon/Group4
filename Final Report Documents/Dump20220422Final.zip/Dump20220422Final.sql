-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ecommercesitedb_new
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_account`
--

DROP TABLE IF EXISTS `customer_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_account` (
  `custAcct_custID` int NOT NULL AUTO_INCREMENT,
  `empAcct_empID` int DEFAULT NULL,
  `custAcct_custFirstName` varchar(50) DEFAULT NULL,
  `custAcct_custLastName` varchar(50) DEFAULT NULL,
  `custAcct_custEmailAddr` varchar(255) DEFAULT NULL,
  `custAcct_custStreet` varchar(50) DEFAULT NULL,
  `custAcct_custCity` varchar(30) DEFAULT NULL,
  `custAcct_custState` varchar(2) DEFAULT NULL,
  `custAcct_custPostalCode` int DEFAULT NULL,
  `custAcct_custPhone` varchar(12) DEFAULT NULL,
  `custAcct_custUserName` varchar(20) DEFAULT NULL,
  `custAcct_custPassword` varchar(15) CHARACTER SET armscii8 COLLATE armscii8_general_ci DEFAULT NULL,
  PRIMARY KEY (`custAcct_custID`),
  KEY `FK_empAcct_empID` (`empAcct_empID`),
  CONSTRAINT `FK_empAcct_empID` FOREIGN KEY (`empAcct_empID`) REFERENCES `employee_account` (`empAcct_empID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1213 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_account`
--

LOCK TABLES `customer_account` WRITE;
/*!40000 ALTER TABLE `customer_account` DISABLE KEYS */;
INSERT INTO `customer_account` VALUES (1100,2,'Lillia','Young','LYoung@outlook.com','6649 N Blue Gum St','New Orleans','LA',70116,'504-621-8927','LYoung','WS622F'),(1101,3,'Jestine','Vaughan','JVaughan@aol.com','4 B Blue Ridge Blvd','Brighton','MI',48116,'810-292-9388','JVaughan','WC822S'),(1102,4,'Darryl','Sutherland','DSutherland@aol.com','8 W Cerritos Ave #54','Bridgeport','NJ',8014,'856-636-8749','DSutherland','MT415R'),(1103,1,'Lelia','Poole','LPoole@gmail.com','639 Main St','Anchorage','AK',99501,'907-385-4412','LPoole','SK880N'),(1104,1,'Sena','Parr','SParr@gmail.com','34 Center St','Hamilton','OH',45011,'513-570-1893','SParr','CT395K'),(1105,3,'Anissa','Nolan','ANolan@aol.com','3 Mcauley Dr','Ashland','OH',44805,'419-503-2484','ANolan','TE754D'),(1106,2,'Rema','Alsop','RAlsop@hotmail.com','7 Eads St','Chicago','IL',60632,'773-573-6914','RAlsop','KN645C'),(1107,1,'Iva','Piper','IPiper@aol.com','7 W Jackson Blvd','San Jose','CA',95111,'408-752-3500','IPiper','VB743J'),(1108,4,'Era','Ball','EBall@hotmail.com','5 Boston Ave #88','Sioux Falls','SD',57105,'605-414-2147','EBall','UB371R'),(1109,2,'Tonia','Piper','TPiper@hotmail.com','228 Runamuck Pl #2808','Baltimore','MD',21224,'410-655-8723','TPiper','HT753Y'),(1110,4,'Sharda','Davies','SDavies@gmail.com','2371 Jerrold Ave','Kulpsville','PA',19443,'215-874-1229','SDavies','YR947I'),(1111,2,'Gwenn','Quinn','GQuinn@aol.com','37275 St Â Rt 17m M','Middle Island','NY',11953,'631-335-3414','GQuinn','UX160V'),(1112,2,'Lachelle','Bell','LBell@aol.com','25 E 75th St #69','Los Angeles','CA',90034,'310-498-5651','LBell','BI857Q'),(1113,2,'Gita','Gill','GGill@aol.com','98 Connecticut Ave Nw','Chagrin Falls','OH',44023,'440-780-8425','GGill','IM128N'),(1114,4,'Theresia','Harris','THarris@aol.com','56 E Morehead St','Laredo','TX',78045,'956-537-6195','THarris','IC610X'),(1115,3,'Lonnie','Poole','LPoole@gmail.com','73 State Road 434 E','Phoenix','AZ',85013,'602-277-4385','LPoole','UY300T'),(1116,3,'Arie','Wright','AWright@hotmail.com','69734 E Carrillo St','Mc Minnville','TN',37110,'931-313-9635','AWright','JN421V'),(1117,2,'Cassidy','Watson','CWatson@outlook.com','322 New Horizon Blvd','Milwaukee','WI',53207,'414-661-9598','CWatson','FU179D'),(1118,5,'Charmain','Blake','CBlake@gmail.com','1 State Route 27','Taylor','MI',48180,'313-288-7937','CBlake','BQ989J'),(1119,2,'Cherlyn','Campbell','CCampbell@gmail.com','394 Manchester Blvd','Rockford','IL',61109,'815-828-2147','CCampbell','VL602P'),(1120,1,'Kristle','Ross','KRoss@gmail.com','6 S 33rd St','Aston','PA',19014,'610-545-3615','KRoss','BA558K'),(1121,4,'Shakia','Powell','SPowell@yahoo.com','6 Greenleaf Ave','San Jose','CA',95111,'408-540-1785','SPowell','VB460I'),(1122,1,'Dimple','Mills','DMills@outlook.com','618 W Yakima Ave','Irving','TX',75062,'972-303-9197','DMills','AT430L'),(1123,4,'Frank','Howard','FHoward@gmail.com','74 S Westgate St','Albany','NY',12204,'518-966-7987','FHoward','UE989O'),(1124,2,'Sommer','Murray','SMurray@aol.com','3273 State St','Middlesex','NJ',8846,'732-658-3154','SMurray','GL267P'),(1125,5,'Tameka','Allan','TAllan@hotmail.com','1 Central Ave','Stevens Point','WI',54481,'715-662-6764','TAllan','LO252H'),(1126,5,'Kelvin','Terry','KTerry@gmail.com','86 Nw 66th St #8673','Shawnee','KS',66218,'913-388-2079','KTerry','RI374V'),(1127,5,'Adina','Carr','ACarr@yahoo.com','2 Cedar Ave #84','Easton','MD',21601,'410-669-1642','ACarr','RM165F'),(1128,3,'Val','Hudson','VHudson@hotmail.com','90991 Thorburn Ave','New York','NY',10011,'212-582-4976','VHudson','XS899O'),(1129,5,'Bethany','Graham','BGraham@hotmail.com','386 9th Ave N','Conroe','TX',77301,'936-336-3951','BGraham','HQ897Y'),(1130,3,'Babara','Robertson','BRobertson@yahoo.com','74874 Atlantic Ave','Columbus','OH',43215,'614-801-9788','BRobertson','KF688I'),(1131,5,'Merlyn','McDonald','MMcDonald@yahoo.com','366 South Dr','Las Cruces','NM',88011,'505-977-3911','MMcDonald','BS175D'),(1132,1,'Shan','Taylor','STaylor@aol.com','45 E Liberty St','Ridgefield Park','NJ',7660,'201-709-6245','STaylor','UT370V'),(1133,1,'Minda','Young','MYoung@gmail.com','4 Ralph Ct','Dunellen','NJ',8812,'732-924-7882','MYoung','EM320I'),(1134,3,'Rusty','Lee','RLee@hotmail.com','2742 Distribution Way','New York','NY',10025,'212-860-1579','RLee','XF518E'),(1135,4,'Melita','Campbell','MCampbell@gmail.com','426 Wolf St','Metairie','LA',70002,'504-979-9175','MCampbell','FS685H'),(1136,3,'Tequila','Peters','TPeters@gmail.com','128 Bransten Rd','New York','NY',10011,'212-675-8570','TPeters','SO902H'),(1137,1,'Claribel','Short','CShort@outlook.com','17 Morena Blvd','Camarillo','CA',93012,'805-832-6163','CShort','AK584B'),(1138,4,'Kandace','Marshall','KMarshall@gmail.com','775 W 17th St','San Antonio','TX',78204,'210-812-9597','KMarshall','TJ512F'),(1139,3,'Emma','Rampling','ERampling@yahoo.com','6980 Dorsett Rd','Abilene','KS',67410,'785-463-7829','ERampling','XK331R'),(1140,5,'Reyes','Baker','RBaker@yahoo.com','2881 Lewis Rd','Prineville','OR',97754,'541-548-8197','RBaker','DG501Y'),(1141,3,'Belen','Taylor','BTaylor@hotmail.com','7219 Woodfield Rd','Overland Park','KS',66204,'913-413-4604','BTaylor','KU513B'),(1142,3,'Darcie','Parr','DParr@aol.com','1048 Main St','Fairbanks','AK',99708,'907-231-4722','DParr','XR110E'),(1143,4,'Margurite','Howard','MHoward@hotmail.com','678 3rd Ave','Miami','FL',33196,'305-606-7291','MHoward','UT190C'),(1144,4,'Ashlyn','Campbell','ACampbell@outlook.com','20 S Babcock St','Fairbanks','AK',99712,'907-741-1044','ACampbell','RZ460H'),(1145,2,'Joslyn','Allan','JAllan@hotmail.com','2 Lighthouse Ave','Hopkins','MN',55343,'952-768-2416','JAllan','HB249C'),(1146,2,'Deanne','Avery','DAvery@gmail.com','38938 Park Blvd','Boston','MA',2128,'617-399-5124','DAvery','BH523Q'),(1147,2,'Efren','Pullman','EPullman@aol.com','5 Tomahawk Dr','Los Angeles','CA',90006,'323-453-2780','EPullman','FK219Z'),(1148,2,'Hayden','Roberts','HRoberts@yahoo.com','762 S Main St','Madison','WI',53711,'608-336-7444','HRoberts','FD907U'),(1149,5,'Susy','Lawrence','SLawrence@yahoo.com','209 Decker Dr','Philadelphia','PA',19132,'215-907-9111','SLawrence','OW437R'),(1150,4,'Twila','Taylor','TTaylor@hotmail.com','4486 W O St #1','New York','NY',10003,'212-402-9216','TTaylor','AB747O'),(1151,5,'Kelley','Morrison','KMorrison@yahoo.com','39 S 7th St','Tullahoma','TN',37388,'931-875-6644','KMorrison','QB947M'),(1152,5,'Eusebio','James','EJames@aol.com','98839 Hawthorne Blvd #6101','Columbia','SC',29201,'803-925-5213','EJames','ZX575O'),(1153,2,'Fallon','Hudson','FHudson@hotmail.com','71 San Mateo Ave','Wayne','PA',19087,'610-814-5533','FHudson','FE873V'),(1154,1,'Suzanna','Gray','SGray@hotmail.com','76 Brooks St #9','Flemington','NJ',8822,'908-877-6135','SGray','HV801F'),(1155,1,'Rikki','James','RJames@yahoo.com','4545 Courthouse Rd','Westbury','NY',11590,'516-968-6051','RJames','AI590V'),(1156,1,'Monte','Edmunds','MEdmunds@aol.com','14288 Foster Ave #4121','Jenkintown','PA',19046,'215-934-8655','MEdmunds','LZ509S'),(1157,2,'Henry','Mills','HMills@gmail.com','4 Otis St','Van Nuys','CA',91405,'818-423-4007','HMills','CQ410G'),(1158,2,'Venice','Turner','VTurner@gmail.com','65895 S 16th St','Providence','RI',2909,'401-458-2547','VTurner','MC949O'),(1159,2,'Krista','Cameron','KCameron@hotmail.com','14302 Pennsylvania Ave','Huntingdon Valley','PA',19006,'215-211-9589','KCameron','GC242Q'),(1160,1,'Alla','Bell','ABell@outlook.com','201 Hawk Ct','Providence','RI',2904,'401-960-8259','ABell','NY690A'),(1161,1,'Darla','Welch','DWelch@aol.com','53075 Sw 152nd Ter #615','Monroe Township','NJ',8831,'732-234-1546','DWelch','WQ752A'),(1162,5,'Eusebio','Dickens','EDickens@outlook.com','59 N Groesbeck Hwy','Austin','TX',78731,'512-486-3817','EDickens','NL236V'),(1163,1,'Adrienne','Johnston','AJohnston@gmail.com','2664 Lewis Rd','Littleton','CO',80126,'303-724-7371','AJohnston','MS780U'),(1164,3,'Jamey','Paterson','JPaterson@outlook.com','59 Shady Ln #53','Milwaukee','WI',53214,'414-748-1374','JPaterson','SQ100L'),(1165,2,'Bettie','McDonald','BMcDonald@yahoo.com','3305 Nabell Ave #679','New York','NY',10009,'212-674-9610','BMcDonald','EA506R'),(1166,4,'Dorsey','Wilson','DWilson@hotmail.com','18 Fountain St','Anchorage','AK',99515,'907-797-9628','DWilson','UT909X'),(1167,3,'Elza','Edmunds','EEdmunds@outlook.com','7 W 32nd St','Erie','PA',16502,'814-393-5571','EEdmunds','SV290N'),(1168,1,'Ingrid','Taylor','ITaylor@aol.com','2853 S Central Expy','Glen Burnie','MD',21061,'410-914-9018','ITaylor','OW632H'),(1169,5,'Rachelle','Vaughan','RVaughan@aol.com','74 W College St','Boise','ID',83707,'208-862-5339','RVaughan','LR624P'),(1170,3,'Jarrett','Campbell','JCampbell@gmail.com','701 S Harrison Rd','San Francisco','CA',94104,'415-315-2761','JCampbell','OK951Z'),(1171,3,'Willy','Graham','WGraham@aol.com','1088 Pinehurst St','Chapel Hill','NC',27514,'919-225-9345','WGraham','QS977S'),(1172,2,'Callie','Dowd','CDowd@gmail.com','30 W 80th St #1995','San Carlos','CA',94070,'650-528-5783','CDowd','JF372R'),(1173,3,'Thelma','Ogden','TOgden@outlook.com','20932 Hedley St','Concord','CA',94520,'925-647-3298','TOgden','NF423L'),(1174,4,'Nichelle','Simpson','NSimpson@hotmail.com','2737 Pistorio Rd #9230','London','OH',43140,'740-343-8575','NSimpson','XK469D'),(1175,4,'Jonie','Vance','JVance@hotmail.com','74989 Brandon St','Wellsville','NY',14895,'585-866-8313','JVance','LC281C'),(1176,1,'Lakesha','Edmunds','LEdmunds@outlook.com','6 Kains Ave','Baltimore','MD',21215,'410-520-4832','LEdmunds','EF946L'),(1177,5,'Pamala','Vaughan','PVaughan@outlook.com','47565 W Grand Ave','Newark','NJ',7105,'973-354-2040','PVaughan','OG851O'),(1178,4,'Un','Hughes','UHughes@aol.com','4284 Dorigo Ln','Chicago','IL',60647,'773-446-5569','UHughes','GH614A'),(1179,3,'Leisha','Watson','LWatson@hotmail.com','6794 Lake Dr E','Newark','NJ',7104,'973-927-3447','LWatson','YU190M'),(1180,1,'Usha','Parr','UParr@hotmail.com','31 Douglas Blvd #950','Clovis','NM',88101,'505-975-8559','UParr','OS417H'),(1181,2,'Dorotha','Berry','DBerry@aol.com','44 W 4th St','Staten Island','NY',10309,'718-332-6527','DBerry','GE469S'),(1182,2,'Kraig','Russell','KRussell@aol.com','11279 Loytan St','Jacksonville','FL',32254,'904-775-4480','KRussell','RH794A'),(1183,1,'Nickie','James','NJames@aol.com','69 Marquette Ave','Hayward','CA',94545,'510-993-3758','NJames','YM467V'),(1184,2,'Marita','Kelly','MKelly@outlook.com','70 W Main St','Beachwood','OH',44122,'216-657-7668','MKelly','KR548M'),(1185,5,'Breann','Fisher','BFisher@gmail.com','461 Prospect Pl #316','Euless','TX',76040,'817-914-7518','BFisher','BD889D'),(1186,4,'Divina','Thomson','DThomson@yahoo.com','47154 Whipple Ave Nw','Gardena','CA',90247,'310-774-7643','DThomson','BA169W'),(1187,2,'Kay','Peters','KPeters@gmail.com','37 Alabama Ave','Evanston','IL',60201,'847-728-7286','KPeters','OT210A'),(1188,3,'Hong','Metcalfe','HMetcalfe@hotmail.com','3777 E Richmond St #900','Akron','OH',44302,'330-537-5358','HMetcalfe','CY588E'),(1189,5,'Gil','Duncan','GDuncan@outlook.com','3 Fort Worth Ave','Philadelphia','PA',19106,'215-255-1641','GDuncan','TU176H'),(1190,3,'Carissa','Paterson','CPaterson@aol.com','4800 Black Horse Pike','Burlingame','CA',94010,'650-803-1936','CPaterson','TI258R'),(1191,5,'Magnolia','Young','MYoung@yahoo.com','83649 W Belmont Ave','San Gabriel','CA',91776,'626-572-1096','MYoung','IZ785D'),(1192,5,'Lovella','Hamilton','LHamilton@yahoo.com','840 15th Ave','Waco','TX',76708,'254-782-8569','LHamilton','UL798X'),(1193,3,'Soo','Henderson','SHenderson@gmail.com','1747 Calle Amanecer #2','Anchorage','AK',99501,'907-870-5536','SHenderson','SC118A'),(1194,4,'Cherish','Wilson','CWilson@gmail.com','99385 Charity St #840','San Jose','CA',95110,'408-703-8505','CWilson','SD300D'),(1195,4,'Nikki','Butler','NButler@outlook.com','68556 Central Hwy','San Leandro','CA',94577,'510-503-7169','NButler','UW552G'),(1196,3,'Janis','McDonald','JMcDonald@hotmail.com','55 Riverside Ave','Indianapolis','IN',46202,'317-722-5066','JMcDonald','FT625M'),(1197,3,'Olene','Gibson','OGibson@gmail.com','7140 University Ave','Rock Springs','WY',82901,'307-704-8713','OGibson','DZ568Q'),(1198,3,'Mariah','Ferguson','MFerguson@gmail.com','64 5th Ave #1153','Mc Lean','VA',22102,'703-235-3937','MFerguson','LM870E'),(1199,5,'Rolf','Marshall','RMarshall@gmail.com','3 Secor Rd','New Orleans','LA',70112,'504-710-5840','RMarshall','RA319P'),(1200,5,'Shiloh','Watson','SWatson@gmail.com','4 Webbs Chapel Rd','Boulder','CO',80303,'303-301-4946','SWatson','JC529O'),(1201,5,'Sharla','Walsh','SWalsh@gmail.com','524 Louisiana Ave Nw','San Leandro','CA',94577,'510-828-7047','SWalsh','ON980L'),(1202,4,'Randolph','Morgan','RMorgan@yahoo.com','185 Blackstone Bldge','Honolulu','HI',96817,'808-892-7943','RMorgan','LY633E'),(1203,1,'Alethia','Allan','AAllan@outlook.com','170 Wyoming Ave','Burnsville','MN',55337,'952-334-9408','AAllan','PX534R'),(1204,2,'Abbie','Mills','AMills@hotmail.com','4 10th St W','High Point','NC',27263,'336-243-5659','AMills','UU660Z'),(1205,1,'Liberty','Chapman','LChapman@aol.com','7 W Pinhook Rd','Lynbrook','NY',11563,'516-509-2347','LChapman','KB611Y'),(1206,3,'Thanh','Wright','TWright@outlook.com','1 Commerce Way','Portland','OR',97224,'503-939-3153','TWright','FW404Z'),(1207,4,'Adrienne','Robertson','ARobertson@gmail.com','64 Lakeview Ave','Beloit','WI',53511,'608-976-7199','ARobertson','LU349C'),(1208,1,'Erlinda','Gibson','EGibson@outlook.com','3 Aspen St','Worcester','MA',1602,'508-429-8576','EGibson','TJ875O'),(1209,5,'Jim','Harris','JHarris@outlook.com','32860 Sierra Rd','Miami','FL',33133,'305-385-9695','JHarris','MH689M'),(1210,3,'Larhonda','Bailey','LBailey@aol.com','555 Main St','Erie','PA',16502,'814-460-2655','LBailey','MV297W'),(1211,1,'Logan','Duncan','LDuncan@yahoo.com','2 Se 3rd Ave','Mesquite','TX',75149,'972-666-3413','LDuncan','OD877U'),(1212,3,'Cami','Morrison','CMorrison@yahoo.com','2239 Shawnee Mission Pky','Tullahoma','TN',37388,'931-273-8709','CMorrison','QZ328V');
/*!40000 ALTER TABLE `customer_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_billing`
--

DROP TABLE IF EXISTS `customer_billing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_billing` (
  `custBill_ID` int NOT NULL AUTO_INCREMENT,
  `custAcct_custID` int DEFAULT NULL,
  `custBill_cardName` varchar(35) NOT NULL,
  `custBill_cardNumber` varchar(19) NOT NULL,
  `custBill_cardExpiration` varchar(6) NOT NULL,
  `custBill_cardCvv` varchar(3) NOT NULL,
  `custBill_cardCompany` varchar(30) NOT NULL,
  PRIMARY KEY (`custBill_ID`),
  KEY `FK2_custAcct_custID` (`custAcct_custID`),
  CONSTRAINT `FK2_custAcct_custID` FOREIGN KEY (`custAcct_custID`) REFERENCES `customer_account` (`custAcct_custID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_billing`
--

LOCK TABLES `customer_billing` WRITE;
/*!40000 ALTER TABLE `customer_billing` DISABLE KEYS */;
INSERT INTO `customer_billing` VALUES (2000,1100,'Lillia Young','4916044641537130','10/27','746','Visa'),(2001,1101,'Jestine Vaughan','4916051567778480','01/26','758','Discover'),(2002,1102,'Darryl Sutherland','4556367783047600','08/25','793','American Express'),(2003,1103,'Lelia Poole','4929665422630070','11/22','957','Wells Fargo'),(2004,1104,'Sena Parr','4716572484832860','10/22','653','Chase'),(2005,1105,'Anissa Nolan','4539172415679940','02/23','351','Capital One'),(2006,1106,'Rema Alsop','4024007168976580','06/22','467','Visa'),(2007,1107,'Iva Piper','4716646400923660','02/24','574','Discover'),(2008,1108,'Era Ball','4929847996519050','02/23','912','American Express'),(2009,1109,'Tonia Piper','4556935088221750','11/22','928','Wells Fargo'),(2010,1110,'Sharda Davies','4929756527472650','04/24','318','Chase'),(2011,1111,'Gwenn Quinn','4024007144369980','07/22','965','Capital One'),(2012,1112,'Lachelle Bell','4532498013772840','03/25','267','Visa'),(2013,1113,'Gita Gill','4481121615579670','10/27','529','Discover'),(2014,1114,'Theresia Harris','4884425884310060','12/22','373','American Express'),(2015,1115,'Lonnie Poole','4024007153551770','06/26','210','Wells Fargo'),(2016,1116,'Arie Wright','4485231347542480','08/26','209','Chase'),(2017,1117,'Cassidy Watson','4556027875077780','10/27','414','Capital One'),(2018,1118,'Charmain Blake','4485373881879190','10/25','825','Visa'),(2019,1119,'Cherlyn Campbell','4485044972920880','11/23','603','Discover'),(2020,1120,'Kristle Ross','4173030047289580','06/25','754','American Express'),(2021,1121,'Shakia Powell','4716108604741310','06/26','929','Wells Fargo'),(2022,1122,'Dimple Mills','4485990041449960','03/22','302','Chase'),(2023,1123,'Frank Howard','4556549993033560','05/27','591','Capital One'),(2024,1124,'Sommer Murray','4024007144497430','03/22','836','Visa'),(2025,1125,'Tameka Allan','4532845869100820','11/25','524','Discover'),(2026,1126,'Kelvin Terry','4532779001203200','11/25','512','American Express'),(2027,1127,'Adina Carr','4485190678928420','10/22','941','Wells Fargo'),(2028,1128,'Val Hudson','4024007159697720','02/27','648','Chase'),(2029,1129,'Bethany Graham','4695602236293400','05/25','144','Capital One'),(2030,1130,'Babara Robertson','4024007115246330','11/22','107','Visa'),(2031,1131,'Merlyn McDonald','4716230658158200','04/23','637','Discover'),(2032,1132,'Shan Taylor','4485899873489200','12/26','680','American Express'),(2033,1133,'Minda Young','4556523336262850','04/23','705','Wells Fargo'),(2034,1134,'Rusty Lee','4485028612826560','08/26','434','Chase'),(2035,1135,'Melita Campbell','4556638287844170','05/24','376','Capital One'),(2036,1136,'Tequila Peters','4716095911089460','07/25','497','Visa'),(2037,1137,'Claribel Short','4485451160619660','06/26','135','Discover'),(2038,1138,'Kandace Marshall','4916362161688360','12/27','435','American Express'),(2039,1139,'Emma Rampling','4916081495931370','03/26','857','Wells Fargo'),(2040,1140,'Reyes Baker','4929936428445930','09/24','319','Chase'),(2041,1141,'Belen Taylor','4024007142589170','09/22','934','Capital One'),(2042,1142,'Darcie Parr','4716894920147720','05/26','982','Visa'),(2043,1143,'Margurite Howard','4024007137003080','04/24','665','Discover'),(2044,1144,'Ashlyn Campbell','4024007102319400','10/22','942','American Express'),(2045,1145,'Joslyn Allan','4716783117780330','04/25','385','Wells Fargo'),(2046,1146,'Deanne Avery','4929305639796530','06/25','813','Chase'),(2047,1147,'Efren Pullman','4916561501653960','12/25','416','Capital One'),(2048,1148,'Hayden Roberts','4532836609308120','03/22','247','Visa'),(2049,1149,'Susy Lawrence','4539131594362150','09/23','519','Discover'),(2050,1150,'Twila Taylor','4916724150574080','08/26','173','American Express'),(2051,1151,'Kelley Morrison','4485021386036480','07/26','941','Wells Fargo'),(2052,1152,'Eusebio James','4929608388083710','12/22','503','Chase'),(2053,1153,'Fallon Hudson','4916237540647230','04/23','267','Capital One'),(2054,1154,'Suzanna Gray','4716388084707450','12/27','577','Visa'),(2055,1155,'Rikki James','4916635863706360','06/22','914','Discover'),(2056,1156,'Monte Edmunds','4556615549030220','04/24','955','American Express'),(2057,1157,'Henry Mills','4024007162244780','06/22','481','Wells Fargo'),(2058,1158,'Venice Turner','4532920179296260','08/23','921','Chase'),(2059,1159,'Krista Cameron','4485612500394640','10/25','444','Capital One'),(2060,1160,'Alla Bell','4532372583991210','01/24','133','Visa'),(2061,1161,'Darla Welch','4532755401011290','12/22','332','Discover'),(2062,1162,'Eusebio Dickens','4539455949278580','10/26','477','American Express'),(2063,1163,'Adrienne Johnston','4485825462121680','03/23','261','Wells Fargo'),(2064,1164,'Jamey Paterson','4929713356706720','07/23','332','Chase'),(2065,1165,'Bettie McDonald','4556663906970810','05/27','693','Capital One'),(2066,1166,'Dorsey Wilson','4916835194370260','09/25','943','Visa'),(2067,1167,'Elza Edmunds','4024007149775340','05/27','124','Discover'),(2068,1168,'Ingrid Taylor','4916249401635120','11/24','649','American Express'),(2069,1169,'Rachelle Vaughan','4024007158043820','09/22','272','Wells Fargo'),(2070,1170,'Jarrett Campbell','4633324069334590','12/25','444','Chase'),(2071,1171,'Willy Graham','4024007176466990','07/27','204','Capital One'),(2072,1172,'Callie Dowd','4539106990973390','03/23','605','Visa'),(2073,1173,'Thelma Ogden','4642413694162240','09/26','512','Discover'),(2074,1174,'Nichelle Simpson','4024007130718840','09/27','162','American Express'),(2075,1175,'Jonie Vance','4916078311456690','07/24','780','Wells Fargo'),(2076,1176,'Lakesha Edmunds','4478990227373020','06/27','180','Chase'),(2077,1177,'Pamala Vaughan','4904624781298790','03/24','917','Capital One'),(2078,1178,'Un Hughes','4024007135987740','12/24','226','Visa'),(2079,1179,'Leisha Watson','4532237723527230','11/24','678','Discover'),(2080,1180,'Usha Parr','4024007127901550','11/27','909','American Express'),(2081,1181,'Dorotha Berry','4641783015674880','10/23','518','Wells Fargo'),(2082,1182,'Kraig Russell','4024007102585640','01/27','422','Chase'),(2083,1183,'Nickie James','4539761995578570','10/27','865','Capital One'),(2084,1184,'Marita Kelly','4485626219552950','05/26','162','Visa'),(2085,1185,'Breann Fisher','4716391476482460','02/22','507','Discover'),(2086,1186,'Divina Thomson','4532349177214500','03/22','577','American Express'),(2087,1187,'Kay Peters','4539183793992760','03/26','474','Wells Fargo'),(2088,1188,'Hong Metcalfe','4539963458489320','11/27','558','Chase'),(2089,1189,'Gil Duncan','4716690398915260','10/26','676','Capital One'),(2090,1190,'Carissa Paterson','4916588425148040','01/24','909','Visa'),(2091,1191,'Magnolia Young','4024007155615820','10/25','684','Discover'),(2092,1192,'Lovella Hamilton','4916233345636620','09/25','758','American Express'),(2093,1193,'Soo Henderson','4532021451094440','06/25','812','Wells Fargo'),(2094,1194,'Cherish Wilson','4248223121477750','01/27','484','Chase'),(2095,1195,'Nikki Butler','4532191524492650','10/22','726','Capital One'),(2096,1196,'Janis McDonald','4556127514140290','04/25','187','Visa'),(2097,1197,'Olene Gibson','4024007141288460','04/25','202','Discover'),(2098,1198,'Mariah Ferguson','4716111981171570','01/24','434','American Express'),(2099,1199,'Rolf Marshall','4716867751645590','07/26','771','Wells Fargo'),(2100,1200,'Shiloh Watson','4539090180072170','10/26','325','Chase'),(2101,1201,'Sharla Walsh','4916625918326100','02/23','848','Capital One'),(2102,1202,'Randolph Morgan','4916532609055540','04/24','295','Visa'),(2103,1203,'Alethia Allan','4716759479445500','11/22','611','Discover'),(2104,1204,'Abbie Mills','4485964018147020','12/24','236','American Express'),(2105,1205,'Liberty Chapman','4539428078062690','05/22','330','Wells Fargo'),(2106,1206,'Thanh Wright','4024007110454660','09/25','951','Chase'),(2107,1207,'Adrienne Robertson','4532848318162170','11/26','371','Capital One'),(2108,1208,'Erlinda Gibson','4716251739057540','06/26','105','Visa'),(2109,1209,'Jim Harris','4916420242287930','06/22','301','Discover'),(2110,1210,'Larhonda Bailey','4024007154226680','10/22','475','American Express'),(2111,1211,'Logan Duncan','4916920038303010','04/23','788','Wells Fargo'),(2112,1212,'Cami Morrison','4716093237126770','03/27','460','Chase');
/*!40000 ALTER TABLE `customer_billing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_account`
--

DROP TABLE IF EXISTS `employee_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_account` (
  `empAcct_empID` int NOT NULL AUTO_INCREMENT,
  `empAcct_empEmail` varchar(255) NOT NULL,
  `empAcct_empFirstName` varchar(50) NOT NULL,
  `empAcct_empLastName` varchar(50) NOT NULL,
  `empAcct_empPhone` varchar(12) DEFAULT NULL,
  `empAcct_empUserName` varchar(20) DEFAULT NULL,
  `empAcct_empPassword` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`empAcct_empID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_account`
--

LOCK TABLES `employee_account` WRITE;
/*!40000 ALTER TABLE `employee_account` DISABLE KEYS */;
INSERT INTO `employee_account` VALUES (1,'jmartinez@gmail.com','Joshua ','Martinez','970-303-1500','jmartinez','APbWmCSK'),(2,'asneddon@gmail.com','Austin','Sneddon','970-245-4511','asneddon','fmmf2Drq'),(3,'tslinkard@gmail.com','Taylor','Slinkard','303-244-1234','tslinkard','TEZMGp47'),(4,'cjohn@gmail.com','Conner','John','720-500-4517','jconner','MpznpJ5v'),(5,'ipoegstra@gmail.com','Ian','Poegstra','970-973-4507','ipoegstra','vwAwRucV');
/*!40000 ALTER TABLE `employee_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shirt_orders`
--

DROP TABLE IF EXISTS `shirt_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shirt_orders` (
  `shirtOrder_ID` int NOT NULL AUTO_INCREMENT,
  `shopCart_ID` int DEFAULT NULL,
  `custBill_ID` int DEFAULT NULL,
  `custAcct_custID` int DEFAULT NULL,
  `shirtOrder_createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `shirtOrder_modifiedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`shirtOrder_ID`),
  KEY `FK2_shopCart_ID` (`shopCart_ID`),
  KEY `FK2_custBill_ID` (`custBill_ID`),
  KEY `FK3_custAcct_custID` (`custAcct_custID`),
  CONSTRAINT `FK2_custBill_ID` FOREIGN KEY (`custBill_ID`) REFERENCES `customer_billing` (`custBill_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK2_shopCart_ID` FOREIGN KEY (`shopCart_ID`) REFERENCES `shopping_cart` (`shopCart_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK3_custAcct_custID` FOREIGN KEY (`custAcct_custID`) REFERENCES `customer_account` (`custAcct_custID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shirt_orders`
--

LOCK TABLES `shirt_orders` WRITE;
/*!40000 ALTER TABLE `shirt_orders` DISABLE KEYS */;
INSERT INTO `shirt_orders` VALUES (1137,52,2000,1100,'2021-07-08 18:39:00','2021-07-08 18:39:00'),(1138,53,2001,1101,'2021-10-23 04:55:00','2021-10-23 04:55:00'),(1139,54,2002,1102,'2021-05-15 22:28:00','2021-05-15 22:28:00'),(1140,55,2003,1103,'2021-02-11 18:27:00','2021-02-11 18:27:00'),(1141,56,2004,1104,'2020-12-09 14:40:00','2020-12-09 14:40:00'),(1142,57,2005,1105,'2022-03-08 22:25:00','2022-03-08 22:25:00'),(1143,58,2006,1106,'2021-10-09 07:50:00','2021-10-09 07:50:00'),(1144,59,2007,1107,'2022-03-19 09:20:00','2022-03-19 09:20:00'),(1145,60,2008,1108,'2022-06-03 17:40:00','2022-06-03 17:40:00'),(1146,61,2009,1109,'2020-12-17 14:25:00','2020-12-17 14:25:00'),(1147,62,2010,1110,'2021-04-21 22:10:00','2021-04-21 22:10:00'),(1148,63,2011,1111,'2021-06-21 10:07:00','2021-06-21 10:07:00'),(1149,64,2012,1112,'2022-03-11 14:23:00','2022-03-11 14:23:00'),(1150,65,2013,1113,'2022-03-31 19:04:00','2022-03-31 19:04:00'),(1151,66,2014,1114,'2022-05-22 14:45:00','2022-05-22 14:45:00'),(1152,67,2015,1115,'2022-03-21 12:20:00','2022-03-21 12:20:00'),(1153,68,2016,1116,'2021-11-08 13:53:00','2021-11-08 13:53:00'),(1154,69,2017,1117,'2021-10-18 04:59:00','2021-10-18 04:59:00'),(1155,70,2018,1118,'2022-01-03 20:23:00','2022-01-03 20:23:00'),(1156,71,2019,1119,'2021-03-14 11:42:00','2021-03-14 11:42:00'),(1157,72,2020,1120,'2021-10-07 18:13:00','2021-10-07 18:13:00'),(1158,73,2021,1121,'2021-08-25 09:24:00','2021-08-25 09:24:00'),(1159,74,2022,1122,'2021-09-19 11:05:00','2021-09-19 11:05:00'),(1160,75,2023,1123,'2022-02-13 09:58:00','2022-02-13 09:58:00'),(1161,76,2024,1124,'2021-04-05 02:47:00','2021-04-05 02:47:00'),(1162,77,2025,1125,'2020-11-26 11:10:00','2020-11-26 11:10:00'),(1163,78,2026,1126,'2022-03-14 22:58:00','2022-03-14 22:58:00'),(1164,79,2027,1127,'2020-12-21 01:44:00','2020-12-21 01:44:00'),(1165,80,2028,1128,'2022-03-25 08:01:00','2022-03-25 08:01:00'),(1166,81,2029,1129,'2022-02-20 07:23:00','2022-02-20 07:23:00'),(1167,82,2030,1130,'2020-10-02 02:09:00','2020-10-02 02:09:00'),(1168,83,2031,1131,'2021-04-12 06:33:00','2021-04-12 06:33:00'),(1169,84,2032,1132,'2021-02-07 04:15:00','2021-02-07 04:15:00'),(1170,85,2033,1133,'2020-11-28 21:55:00','2020-11-28 21:55:00'),(1171,86,2034,1134,'2021-12-05 01:20:00','2021-12-05 01:20:00'),(1172,87,2035,1135,'2022-04-29 15:43:00','2022-04-29 15:43:00'),(1173,88,2036,1136,'2020-12-10 00:09:00','2020-12-10 00:09:00'),(1174,89,2037,1137,'2021-11-16 10:36:00','2021-11-16 10:36:00'),(1175,90,2038,1138,'2022-06-06 21:24:00','2022-06-06 21:24:00'),(1176,91,2039,1139,'2020-12-10 18:03:00','2020-12-10 18:03:00'),(1177,92,2040,1140,'2021-01-25 03:50:00','2021-01-25 03:50:00'),(1178,93,2041,1141,'2021-01-21 17:32:00','2021-01-21 17:32:00'),(1179,94,2042,1142,'2022-01-22 14:59:00','2022-01-22 14:59:00'),(1180,95,2043,1143,'2022-03-19 02:41:00','2022-03-19 02:41:00'),(1181,96,2044,1144,'2020-12-24 10:15:00','2020-12-24 10:15:00'),(1182,97,2045,1145,'2020-12-30 17:39:00','2020-12-30 17:39:00'),(1183,98,2046,1146,'2021-12-02 03:40:00','2021-12-02 03:40:00'),(1184,99,2047,1147,'2022-02-10 01:51:00','2022-02-10 01:51:00'),(1185,100,2048,1148,'2022-03-19 23:28:00','2022-03-19 23:28:00'),(1186,101,2049,1149,'2021-09-18 18:43:00','2021-09-18 18:43:00'),(1187,102,2050,1150,'2021-08-02 15:57:00','2021-08-02 15:57:00'),(1188,103,2051,1151,'2022-06-19 10:16:00','2022-06-19 10:16:00'),(1189,104,2052,1152,'2021-02-14 06:15:00','2021-02-14 06:15:00'),(1190,105,2053,1153,'2022-07-08 21:05:00','2022-07-08 21:05:00'),(1191,106,2054,1154,'2022-06-20 01:45:00','2022-06-20 01:45:00'),(1192,107,2055,1155,'2021-08-29 15:50:00','2021-08-29 15:50:00'),(1193,108,2056,1156,'2021-09-17 08:46:00','2021-09-17 08:46:00'),(1194,109,2057,1157,'2021-07-01 21:59:00','2021-07-01 21:59:00'),(1195,110,2058,1158,'2022-02-20 08:11:00','2022-02-20 08:11:00'),(1196,111,2059,1159,'2022-01-25 20:42:00','2022-01-25 20:42:00'),(1197,112,2060,1160,'2021-10-02 13:12:00','2021-10-02 13:12:00'),(1198,113,2061,1161,'2021-12-19 20:07:00','2021-12-19 20:07:00'),(1199,114,2062,1162,'2020-10-09 17:13:00','2020-10-09 17:13:00'),(1200,115,2063,1163,'2020-10-23 02:27:00','2020-10-23 02:27:00'),(1201,116,2064,1164,'2022-05-18 01:43:00','2022-05-18 01:43:00'),(1202,117,2065,1165,'2022-01-22 21:08:00','2022-01-22 21:08:00'),(1203,118,2066,1166,'2021-08-25 15:21:00','2021-08-25 15:21:00'),(1204,119,2067,1167,'2022-06-24 14:46:00','2022-06-24 14:46:00'),(1205,120,2068,1168,'2021-07-18 12:38:00','2021-07-18 12:38:00'),(1206,121,2069,1169,'2021-01-01 10:36:00','2021-01-01 10:36:00'),(1207,122,2070,1170,'2021-12-29 17:10:00','2021-12-29 17:10:00'),(1208,123,2071,1171,'2021-09-04 07:42:00','2021-09-04 07:42:00'),(1209,124,2072,1172,'2022-04-28 03:53:00','2022-04-28 03:53:00'),(1210,125,2073,1173,'2021-05-13 03:33:00','2021-05-13 03:33:00'),(1211,126,2074,1174,'2022-02-19 06:55:00','2022-02-19 06:55:00'),(1212,127,2075,1175,'2021-10-30 01:25:00','2021-10-30 01:25:00'),(1213,128,2076,1176,'2021-12-23 14:00:00','2021-12-23 14:00:00'),(1214,129,2077,1177,'2021-11-28 02:12:00','2021-11-28 02:12:00'),(1215,130,2078,1178,'2021-03-03 13:04:00','2021-03-03 13:04:00'),(1216,131,2079,1179,'2021-08-26 18:01:00','2021-08-26 18:01:00'),(1217,132,2080,1180,'2021-08-26 13:35:00','2021-08-26 13:35:00'),(1218,133,2081,1181,'2022-04-14 15:07:00','2022-04-14 15:07:00'),(1219,134,2082,1182,'2021-09-23 16:56:00','2021-09-23 16:56:00'),(1220,135,2083,1183,'2021-10-30 17:05:00','2021-10-30 17:05:00'),(1221,136,2084,1184,'2021-03-14 02:54:00','2021-03-14 02:54:00'),(1222,137,2085,1185,'2020-11-11 23:05:00','2020-11-11 23:05:00'),(1223,138,2086,1186,'2021-04-07 08:57:00','2021-04-07 08:57:00'),(1224,139,2087,1187,'2021-01-28 12:57:00','2021-01-28 12:57:00'),(1225,140,2088,1188,'2021-04-12 16:26:00','2021-04-12 16:26:00'),(1226,141,2089,1189,'2022-04-10 00:09:00','2022-04-10 00:09:00'),(1227,142,2090,1190,'2021-09-14 12:08:00','2021-09-14 12:08:00'),(1228,143,2091,1191,'2021-11-28 14:58:00','2021-11-28 14:58:00'),(1229,144,2092,1192,'2022-05-14 01:43:00','2022-05-14 01:43:00'),(1230,145,2093,1193,'2022-06-30 12:31:00','2022-06-30 12:31:00'),(1231,146,2094,1194,'2021-02-03 07:31:00','2021-02-03 07:31:00'),(1232,147,2095,1195,'2021-10-03 23:14:00','2021-10-03 23:14:00'),(1233,148,2096,1196,'2022-06-07 17:16:00','2022-06-07 17:16:00'),(1234,149,2097,1197,'2021-02-23 10:11:00','2021-02-23 10:11:00'),(1235,150,2098,1198,'2022-02-09 19:21:00','2022-02-09 19:21:00'),(1236,151,2099,1199,'2020-10-05 07:14:00','2020-10-05 07:14:00'),(1237,152,2100,1200,'2021-04-13 11:01:00','2021-04-13 11:01:00'),(1238,153,2101,1201,'2021-09-28 18:54:00','2021-09-28 18:54:00'),(1239,154,2102,1202,'2022-06-29 00:04:00','2022-06-29 00:04:00'),(1240,155,2103,1203,'2022-04-20 22:04:00','2022-04-20 22:04:00'),(1241,156,2104,1204,'2022-01-02 07:40:00','2022-01-02 07:40:00'),(1242,157,2105,1205,'2021-03-12 17:02:00','2021-03-12 17:02:00'),(1243,158,2106,1206,'2022-03-12 23:10:00','2022-03-12 23:10:00'),(1244,159,2107,1207,'2022-06-09 12:34:00','2022-06-09 12:34:00'),(1245,160,2108,1208,'2022-06-21 19:02:00','2022-06-21 19:02:00'),(1246,161,2109,1209,'2021-07-06 23:02:00','2021-07-06 23:02:00'),(1247,162,2110,1210,'2022-04-25 04:19:00','2022-04-25 04:19:00'),(1248,163,2111,1211,'2021-11-30 03:43:00','2021-11-30 03:43:00');
/*!40000 ALTER TABLE `shirt_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shirt_specifics`
--

DROP TABLE IF EXISTS `shirt_specifics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shirt_specifics` (
  `shirtSpec_ID` int NOT NULL AUTO_INCREMENT,
  `shirtSpec_price` decimal(5,2) NOT NULL,
  `shirtSpec_discountedPrice` decimal(5,2) DEFAULT NULL,
  `shirtSpec_material` varchar(20) DEFAULT NULL,
  `shirtSpec_mensSizes` varchar(15) DEFAULT NULL,
  `shirtSpec_womensSizes` varchar(15) DEFAULT NULL,
  `shirtSpec_toddlerSizes` varchar(15) DEFAULT NULL,
  `shirtSpec_youthSizes` varchar(15) DEFAULT NULL,
  `shirtSpec_availability` tinyint DEFAULT NULL,
  `shirtSpec_image` blob,
  `empAcct_empID` int DEFAULT NULL,
  `shopCart_ID` int DEFAULT NULL,
  `shirtType_ID` int DEFAULT NULL,
  `custAcct_custID` int DEFAULT NULL,
  PRIMARY KEY (`shirtSpec_ID`),
  KEY `FK3_empAcct_empID` (`empAcct_empID`),
  KEY `FK_shopCart_ID` (`shopCart_ID`),
  KEY `FK_shirtType_ID` (`shirtType_ID`),
  KEY `FK_custAcct_custID_idx` (`custAcct_custID`),
  CONSTRAINT `FK3_empAcct_empID` FOREIGN KEY (`empAcct_empID`) REFERENCES `employee_account` (`empAcct_empID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_custAcct_custID` FOREIGN KEY (`custAcct_custID`) REFERENCES `customer_account` (`custAcct_custID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_shirtType_ID` FOREIGN KEY (`shirtType_ID`) REFERENCES `shirt_types` (`shirtType_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_shopCart_ID` FOREIGN KEY (`shopCart_ID`) REFERENCES `shopping_cart` (`shopCart_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shirt_specifics`
--

LOCK TABLES `shirt_specifics` WRITE;
/*!40000 ALTER TABLE `shirt_specifics` DISABLE KEYS */;
INSERT INTO `shirt_specifics` VALUES (22,20.00,0.00,'Cotton','M','','','',1,_binary 'Yes',1,52,1,1100),(23,20.00,0.00,'Cotton','L','','','',1,_binary 'Yes',1,53,2,1101),(24,20.00,5.99,'Polyester','XL','','','',1,_binary 'Yes',2,54,3,1102),(25,20.00,0.00,'Cotton','','S','','',1,_binary 'Yes',2,55,1,1103),(26,20.00,0.00,'Cotton','','M','','',0,_binary 'Yes',2,56,2,1104),(27,20.00,5.99,'Cotton','','L','','',1,_binary 'Yes',3,57,3,1105),(28,20.00,0.00,'Polyester','','','2T','',1,_binary 'Yes',3,58,1,1106),(29,20.00,0.00,'Polyester','','','3T','',1,_binary 'Yes',3,59,2,1107),(30,20.00,5.99,'Cotton','','','4T','',1,_binary 'Yes',4,60,3,1108),(31,20.00,0.00,'Cotton','','','','5T',0,_binary 'Yes',4,61,1,1109),(32,20.00,0.00,'Polyester','','','','6T',1,_binary 'Yes',5,62,2,1110),(33,20.00,5.99,'Cotton','','','','7T',1,'',5,63,3,1111);
/*!40000 ALTER TABLE `shirt_specifics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shirt_types`
--

DROP TABLE IF EXISTS `shirt_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shirt_types` (
  `shirtType_ID` int NOT NULL,
  `shirtType_Type` varchar(20) NOT NULL,
  PRIMARY KEY (`shirtType_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shirt_types`
--

LOCK TABLES `shirt_types` WRITE;
/*!40000 ALTER TABLE `shirt_types` DISABLE KEYS */;
INSERT INTO `shirt_types` VALUES (1,'plain'),(2,'active '),(3,'graphic');
/*!40000 ALTER TABLE `shirt_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_cart`
--

DROP TABLE IF EXISTS `shopping_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_cart` (
  `shopCart_ID` int NOT NULL AUTO_INCREMENT,
  `shopCart_qty` int DEFAULT NULL,
  `shopCart_createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `shopCart_modifiedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`shopCart_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_cart`
--

LOCK TABLES `shopping_cart` WRITE;
/*!40000 ALTER TABLE `shopping_cart` DISABLE KEYS */;
INSERT INTO `shopping_cart` VALUES (52,1,'2021-07-08 18:34:00','2021-07-08 18:34:00'),(53,7,'2021-10-23 04:51:00','2021-10-23 04:51:00'),(54,6,'2021-05-15 22:27:00','2021-05-15 22:27:00'),(55,5,'2021-02-11 18:26:00','2021-02-11 18:26:00'),(56,6,'2020-12-09 14:39:00','2020-12-09 14:39:00'),(57,2,'2022-03-08 22:24:00','2022-03-08 22:24:00'),(58,3,'2021-10-09 07:49:00','2021-10-09 07:49:00'),(59,2,'2022-03-19 09:19:00','2022-03-19 09:19:00'),(60,5,'2022-06-03 17:39:00','2022-06-03 17:39:00'),(61,2,'2020-12-17 14:24:00','2020-12-17 14:24:00'),(62,6,'2021-04-21 22:09:00','2021-04-21 22:09:00'),(63,5,'2021-06-21 10:06:00','2021-06-21 10:06:00'),(64,6,'2022-03-11 14:22:00','2022-03-11 14:22:00'),(65,6,'2022-03-31 19:03:00','2022-03-31 19:03:00'),(66,4,'2022-05-22 14:44:00','2022-05-22 14:44:00'),(67,5,'2022-03-21 12:19:00','2022-03-21 12:19:00'),(68,4,'2021-11-08 13:52:00','2021-11-08 13:52:00'),(69,4,'2021-10-18 04:59:00','2021-10-18 04:59:00'),(70,5,'2022-01-03 20:22:00','2022-01-03 20:22:00'),(71,7,'2021-03-14 11:41:00','2021-03-14 11:41:00'),(72,5,'2021-10-07 18:12:00','2021-10-07 18:12:00'),(73,1,'2021-08-25 09:23:00','2021-08-25 09:23:00'),(74,5,'2021-09-19 11:04:00','2021-09-19 11:04:00'),(75,1,'2022-02-13 09:57:00','2022-02-13 09:57:00'),(76,3,'2021-04-05 02:46:00','2021-04-05 02:46:00'),(77,7,'2020-11-26 11:09:00','2020-11-26 11:09:00'),(78,5,'2022-03-14 22:57:00','2022-03-14 22:57:00'),(79,2,'2020-12-21 01:43:00','2020-12-21 01:43:00'),(80,4,'2022-03-25 08:00:00','2022-03-25 08:00:00'),(81,1,'2022-02-20 07:22:00','2022-02-20 07:22:00'),(82,5,'2020-10-02 02:08:00','2020-10-02 02:08:00'),(83,3,'2021-04-12 06:33:00','2021-04-12 06:33:00'),(84,7,'2021-02-07 04:14:00','2021-02-07 04:14:00'),(85,2,'2020-11-28 21:54:00','2020-11-28 21:54:00'),(86,7,'2021-12-05 01:19:00','2021-12-05 01:19:00'),(87,3,'2022-04-29 15:42:00','2022-04-29 15:42:00'),(88,5,'2020-12-10 00:08:00','2020-12-10 00:08:00'),(89,1,'2021-11-16 10:35:00','2021-11-16 10:35:00'),(90,7,'2022-06-06 21:23:00','2022-06-06 21:23:00'),(91,5,'2020-12-10 18:02:00','2020-12-10 18:02:00'),(92,3,'2021-01-25 03:49:00','2021-01-25 03:49:00'),(93,2,'2021-01-21 17:31:00','2021-01-21 17:31:00'),(94,7,'2022-01-22 14:58:00','2022-01-22 14:58:00'),(95,4,'2022-03-19 02:40:00','2022-03-19 02:40:00'),(96,1,'2020-12-24 10:14:00','2020-12-24 10:14:00'),(97,3,'2020-12-30 17:38:00','2020-12-30 17:38:00'),(98,3,'2021-12-02 03:39:00','2021-12-02 03:39:00'),(99,4,'2022-02-10 01:49:00','2022-02-10 01:49:00'),(100,5,'2022-03-19 23:27:00','2022-03-19 23:27:00'),(101,6,'2021-09-18 18:42:00','2021-09-18 18:42:00'),(102,7,'2021-08-02 15:56:00','2021-08-02 15:56:00'),(103,5,'2022-06-19 10:15:00','2022-06-19 10:15:00'),(104,2,'2021-02-14 06:14:00','2021-02-14 06:14:00'),(105,1,'2022-07-08 21:04:00','2022-07-08 21:04:00'),(106,5,'2022-06-20 01:44:00','2022-06-20 01:44:00'),(107,7,'2021-08-29 15:49:00','2021-08-29 15:49:00'),(108,1,'2021-09-17 08:45:00','2021-09-17 08:45:00'),(109,5,'2021-07-01 21:58:00','2021-07-01 21:58:00'),(110,2,'2022-02-20 08:10:00','2022-02-20 08:10:00'),(111,1,'2022-01-25 20:41:00','2022-01-25 20:41:00'),(112,2,'2021-10-02 13:11:00','2021-10-02 13:11:00'),(113,1,'2021-12-19 20:06:00','2021-12-19 20:06:00'),(114,1,'2020-10-09 17:12:00','2020-10-09 17:12:00'),(115,7,'2020-10-23 02:26:00','2020-10-23 02:26:00'),(116,7,'2022-05-18 01:42:00','2022-05-18 01:42:00'),(117,3,'2022-01-22 21:07:00','2022-01-22 21:07:00'),(118,5,'2021-08-25 15:20:00','2021-08-25 15:20:00'),(119,2,'2022-06-24 14:45:00','2022-06-24 14:45:00'),(120,7,'2021-07-18 12:38:00','2021-07-18 12:38:00'),(121,7,'2021-01-01 10:35:00','2021-01-01 10:35:00'),(122,4,'2021-12-29 17:09:00','2021-12-29 17:09:00'),(123,6,'2021-09-04 07:42:00','2021-09-04 07:42:00'),(124,4,'2022-04-28 03:52:00','2022-04-28 03:52:00'),(125,2,'2021-05-13 03:32:00','2021-05-13 03:32:00'),(126,5,'2022-02-19 06:54:00','2022-02-19 06:54:00'),(127,3,'2021-10-30 01:24:00','2021-10-30 01:24:00'),(128,3,'2021-12-23 13:59:00','2021-12-23 13:59:00'),(129,4,'2021-11-28 02:11:00','2021-11-28 02:11:00'),(130,2,'2021-03-03 13:04:00','2021-03-03 13:04:00'),(131,4,'2021-08-26 18:00:00','2021-08-26 18:00:00'),(132,1,'2021-08-26 13:34:00','2021-08-26 13:34:00'),(133,4,'2022-04-14 15:06:00','2022-04-14 15:06:00'),(134,4,'2021-09-23 16:55:00','2021-09-23 16:55:00'),(135,6,'2021-10-30 17:04:00','2021-10-30 17:04:00'),(136,3,'2021-03-14 02:53:00','2021-03-14 02:53:00'),(137,6,'2020-11-11 23:04:00','2020-11-11 23:04:00'),(138,5,'2021-04-07 08:56:00','2021-04-07 08:56:00'),(139,2,'2021-01-28 12:56:00','2021-01-28 12:56:00'),(140,6,'2021-04-12 16:25:00','2021-04-12 16:25:00'),(141,2,'2022-04-10 00:08:00','2022-04-10 00:08:00'),(142,5,'2021-09-14 12:07:00','2021-09-14 12:07:00'),(143,7,'2021-11-28 14:54:00','2021-11-28 14:54:00'),(144,4,'2022-05-14 01:42:00','2022-05-14 01:42:00'),(145,2,'2022-06-30 12:30:00','2022-06-30 12:30:00'),(146,4,'2021-02-03 07:30:00','2021-02-03 07:30:00'),(147,5,'2021-10-03 23:13:00','2021-10-03 23:13:00'),(148,4,'2022-06-07 17:15:00','2022-06-07 17:15:00'),(149,7,'2021-02-23 10:10:00','2021-02-23 10:10:00'),(150,6,'2022-02-09 19:20:00','2022-02-09 19:20:00'),(151,4,'2020-10-05 07:13:00','2020-10-05 07:13:00'),(152,4,'2021-04-13 11:00:00','2021-04-13 11:00:00'),(153,4,'2021-09-28 18:53:00','2021-09-28 18:53:00'),(154,2,'2022-06-29 00:03:00','2022-06-29 00:03:00'),(155,1,'2022-04-20 22:03:00','2022-04-20 22:03:00'),(156,3,'2022-01-02 07:39:00','2022-01-02 07:39:00'),(157,6,'2021-03-12 17:01:00','2021-03-12 17:01:00'),(158,4,'2022-03-12 23:09:00','2022-03-12 23:09:00'),(159,5,'2022-06-09 12:33:00','2022-06-09 12:33:00'),(160,1,'2022-06-21 19:01:00','2022-06-21 19:01:00'),(161,3,'2021-07-06 23:01:00','2021-07-06 23:01:00'),(162,1,'2022-04-25 04:18:00','2022-04-25 04:18:00'),(163,5,'2021-11-30 03:42:00','2021-11-30 03:42:00'),(164,7,'2022-06-23 16:30:00','2022-06-23 16:30:00');
/*!40000 ALTER TABLE `shopping_cart` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-22 18:09:23
